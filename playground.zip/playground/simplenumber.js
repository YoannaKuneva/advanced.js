// 12 зад.
function simpleNumber(number) {
    let count = 0;
    for (let i = 2; i < number; i++) {
        if (number % i == 0) {
            count++;
            break;
        }
    }
    if (count == 0) return 'Просто число';
    else return 'Числото не е просто';
}

module.exports = { simpleNumber };