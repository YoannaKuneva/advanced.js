// 1 зад.
let expect = require("chai").expect;
let sum = require("./index").sum;  

describe("sum(arr) - sum array of numbers", function () {
    
    it("should return 5 for ['1','2','2']", function () {
        expect(sum(['1','2','2'])).to.be.equal(5);
    });

});


// 2 зад.
// let expect = require("chai").expect;
// let calSumAndVat = require("./vat").calSumAndVat;

// describe("Sum + Vat = Total is ", function () {
    
//     it("should return 8.64 for ['1.50', '2.70', '3.00']", function () {
//         expect(calSumAndVat(['1.50', '2.70', '3.00'])).to.be.equal(8.64);
//     });

// });


// 3 зад.
// let expect = require("chai").expect;
// let countLetter = require("./letter").countLetter;  

// describe("countLetter is ", function () {
    
//     it("should return 2 for ['hello', 'l']", function () {
//         expect(countLetter(['hello', 'l'])).to.be.equal(2);
//     });

// });


// 4 зад.
// let expect = require("chai").expect;
// let figureArea = require("./figure").figureArea;  

// describe("figureArea is ", function () {
    
//     it("should return 17 for ['2', '4', '5', '3']", function () {
//         expect(figureArea(['2', '4', '5', '3'])).to.be.equal(17);
//     });

// });


// 5 зад.
// let expect = require("chai").expect;
// let leapYear = require("./year").leapYear;  

// describe("leapYear calculate specific year", function () {
    
//     it("should return Yes for 2020", function () {
//         expect(leapYear(2020)).to.be.equal('Yes');
//     });

// });


// 6 зад.
// let expect = require("chai").expect;
// let stringOfNumbers = require("./stringnums").stringOfNumbers;  

// describe("stringOfNumbers is ", function () {
    
//     it("should return 12345678910 for 10", function () {
//         expect(stringOfNumbers(10)).to.be.equal('12345678910');
//     });

// });


// 7 зад.
// let expect = require("chai").expect;
// let distancePoints = require("./points").distancePoints;  

// describe("distancePoints is ", function () {
    
//     it("should return 5 for ['2', '4', '5', '0']", function () {
//         expect(distancePoints(['2', '4', '5', '0'])).to.be.equal(5);
//     });

// });


// 8 зад.
// let expect = require("chai").expect;
// let boxesAndBottles = require("./boxes").boxesAndBottles;  

// describe("boxesAndBottles calculate boxes", function () {
    
//         it("should return 4 for (20, 5)", function () {
//             expect(boxesAndBottles(20, 5)).to.be.equal(4);
//         });
    
//     });


// 9 зад.
// let expect = require("chai").expect;
// let triangleArea = require("./triangle").triangleArea;  

// describe("triangleArea is ", function () {
    
//     it("should return 6 for ['3', '4', '5']", function () {
//         expect(triangleArea(['3', '4', '5'])).to.be.equal(6);
//     });

// });


// 10 зад.
// let expect = require("chai").expect;
// let cone = require("./cone").cone;  

// describe("Volume: ", function () {
    
//     it("should return 47.1238898038469 for ['3', '5']", function () {
//         expect(cone(['3', '5'])).to.be.equal(47.1238898038469);
//     });

// });


// 11 зад.
// let expect = require("chai").expect;
// let oddOrEven = require("./even").oddOrEven;  

// describe("The number is ", function () {
    
//     it("should return even for 2", function () {
//         expect(oddOrEven(2)).to.be.equal('even');
//     });

// })


// 12 зад.
// let expect = require("chai").expect;
// let simpleNumber = require("./simplenumber").simpleNumber;  

// describe("simpleNumber is ", function () {
    
//     it("should return Числото не е просто for 8", function () {
//         expect(simpleNumber(8)).to.be.equal('Числото не е просто');
//     });

//     it("should return Просто число for 2", function () {
//         expect(simpleNumber(2)).to.be.equal('Просто число');
//     });

// });


// 13 зад.
// let expect = require("chai").expect;
// let distanceTime = require("./distance").distanceTime;  

// describe("Distance from S1 to S2: ", function () {
    
//     it("should return 60000 for ['50', '20', '7200']", function () {
//         expect(distanceTime(['50', '20', '7200'])).to.be.equal(60000);
//     });

// });


// 14 зад.
// let expect = require("chai").expect;
// let prop = require("./props").prop;  

// describe("props is ", function () {
    
//     it("should return name: Yoanna age: 24 gender: female for ['name', 'Yoanna', 'age', '24', 'gender', 'female']", function () {
//         expect(prop(['name', 'Yoanna', 'age', '24', 'gender', 'female'])).to.be.equal('name: Yoanna, age: 24, gender: female');
//     });

// });


// 15 зад.
// let expect = require("chai").expect;
// let biggest = require("./biggest").biggest;  

// describe("The biggest number ", function () {
    
//     it("should return 97 for ['-2', '67', '97']", function () {
//         expect(biggest(['-2', '67', '97'])).to.be.equal(97);
//     });

// });


// 16 зад.
// let expect = require("chai").expect;
// let calculate = require("./calculator").calculate;  

// describe("Calculate sum ", function () {
    
//     it("should return 10 for ['8', '2', '+']", function () {
//         expect(calculate(['8', '2', '+'])).to.be.equal(10);
//     });

//     it("should return 6 for ['8', '2', '-']", function () {
//         expect(calculate(['8', '2', '-'])).to.be.equal(6);
//     });

//     it("should return 16 for ['8', '2', '*']", function () {
//         expect(calculate(['8', '2', '*'])).to.be.equal(16);
//     });

//     it("should return 4 for ['8', '2', '/']", function () {
//         expect(calculate(['8', '2', '/'])).to.be.equal(4);
//     });
// });


// 17 зад.
// let expect = require("chai").expect;
// let upperCase = require("./uppercase").upperCase;  

// describe("upperCase... ", function () {
    
//     it("should return HI, HOW ARE YOU? for ('Hi, how are you?')", function () {
//         expect(upperCase('Hi, how are you?')).to.be.equal('HI, HOW ARE YOU?');
//     });

// });