// 17 зад.
function upperCase () {
    let string = new String('Hi, how are you?');
    return string.toUpperCase();
}

module.exports = { upperCase };