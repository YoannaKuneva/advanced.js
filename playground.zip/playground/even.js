// 11 зад.
function oddOrEven(number) {
    if (number % 1 == 0) {
        if (number % 2 == 0) {
            return 'even';
        } else {
            return 'odd';
        }
    } else {
        return 'invalid';    
    }
}

module.exports = { oddOrEven };