// 8 зад.
function boxesAndBottles(bottles, capacity) {
    let result = Math.ceil(bottles / capacity);
    return result;
}

module.exports = { boxesAndBottles };
