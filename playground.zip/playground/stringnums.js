// 6 зад.
function stringOfNumbers(lastNum) {
    let result = '';
    for (let i = 1; i <= lastNum; i++) {
        result += i;
    }
    return result;
}

module.exports = { stringOfNumbers };