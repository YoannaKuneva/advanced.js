// 2 зад.
function calSumAndVat(arr) {
    let sum = 0;
    for (let price of arr){
        sum += Number(price);
    }
    let vat = sum * 0.2;
    let total = sum + vat;
    return total;
}

module.exports = { calSumAndVat };